// $(document).ready(function(){
//     alert("ready")
//     // $.ajax({
//     //     type: "POST",
//     //     url: "/user/home",
//     //     data: {friendName:, authenticity_token:$('meta[name="csrf-token"]').attr("content")},
//     //     dataType: "json",
//     //     success: function (response) {
//     //         if(response['friend']){
//     //             $("#invited_to_order").append('<div><i class="invitedName">'+response['friend'].username+'</i>'
//     //                 +'<button type="button" onclick="removeFromList(this)" id="'+response['friend'].id+'" value="'+response['friend'].username+'">remove</button>'
//     //                 +'<br></div>')
//     //             friendsList.push(response['friend'].id)
//     //             nameList.push(response['friend'].username)
//     //         }else if(response['NotFriend']){
//     //             alert("User is not your friend!!")
//     //         }else{
//     //             alert("User is not found!")
//     //         }
//     //     }
//     // });
// })
;
